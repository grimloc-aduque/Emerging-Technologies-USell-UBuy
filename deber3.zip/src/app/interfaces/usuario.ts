export interface Usuario {
    nombre: String;
    apellido: String;
    celular: String;
    correo: String;
    carrera: String;
}
