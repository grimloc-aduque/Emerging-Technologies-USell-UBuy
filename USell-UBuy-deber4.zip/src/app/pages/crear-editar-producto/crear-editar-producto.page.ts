import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-editar-producto',
  templateUrl: './crear-editar-producto.page.html',
  styleUrls: ['./crear-editar-producto.page.scss'],
})
export class CrearEditarProductoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
