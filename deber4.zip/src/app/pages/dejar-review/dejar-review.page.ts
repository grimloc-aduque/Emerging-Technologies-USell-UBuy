import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dejar-review',
  templateUrl: './dejar-review.page.html',
  styleUrls: ['./dejar-review.page.scss'],
})
export class DejarReviewPage implements OnInit {

  datosPerfil = [
    {
      calificacionComoVendedor: '4',
    }
  ]

  constructor() { }

  ngOnInit() {
  }

}
