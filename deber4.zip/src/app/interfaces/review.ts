export interface Review {
    _id: String,
    calificacion: number,
    comentario: String,
    fecha: String[],
    id_producto: String,
    id_comprador: String,
    id_vendedor: String
}