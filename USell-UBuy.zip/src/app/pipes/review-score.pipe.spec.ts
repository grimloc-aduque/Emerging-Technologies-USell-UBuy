import { ReviewScorePipe } from './review-score.pipe';

describe('ReviewScorePipe', () => {
  it('create an instance', () => {
    const pipe = new ReviewScorePipe();
    expect(pipe).toBeTruthy();
  });
});
