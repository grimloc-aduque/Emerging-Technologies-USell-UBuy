export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBgb4GxuKmb7eQEIQbX-CFZOX5nEzdCTxg",
    authDomain: "usell-ubuy-d09e5.firebaseapp.com",
    projectId: "usell-ubuy-d09e5",
    storageBucket: "usell-ubuy-d09e5.appspot.com",
    messagingSenderId: "903806962906",
    appId: "1:903806962906:web:2a4c518d3e9a83e82029e3"
  }  
};
